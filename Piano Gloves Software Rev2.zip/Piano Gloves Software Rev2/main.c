// main.c
// Authors: Eric Nguyen, Naomi George
// Created: October 12,2020
// Description: 
// Test code for VL53L0X sensor. 
// Library used: https://github.com/ZeeLivermorium/VL53L0X_TM4C123G
// Libray author: Zee Livermorium

/* hardware connections
 ST7735
 Backlight (pin 10) connected to +3.3 V
 MISO (pin 9) unconnected/ SCK (pin 8) connected to PA2 (SSI0Clk)
 MOSI (pin 7) connected to PA5 (SSI0Tx)
 TFT_CS (pin 6) connected to PA3 (SSI0Fss)
 CARD_CS (pin 5) unconnected
 Data/Command (pin 4) connected to PA6 (GPIO), high for data, low for command
 RESET (pin 3) connected to PA7 (GPIO)
 VCC (pin 2) connected to +3.3 V
 Gnd (pin 1) connected to ground
 VL53L0X
 VCC (pin 1) connected to +3.3 V
 Gnd (pin 2) connected to ground
 SCL (pin 3) connected to PB2 (I2C0SCL)
 SDA (pin 4) connected to PB3 (I2C0SDA)
 XSHUT (pin 5) unconnected
*/
// Bluetooth connections
// Tiva -------- HC05 Bluetooth Module
// PD6   ------  TXD
// PC7   ------  RXD
// 3.3v  ------  Vc
// gnd   ------  gnd
// ADC1 connections
// Tiva -------- Flex sensors
// PE0   ------  flex sensor 1
// PE1   ------  flex sensor 2
// PE2   ------  flex sensor 3
// PE3   ------  flex sensor 4
// PE4   ------  flex sensor 5
#include <stdint.h>
#include <stdio.h>
#include <stdbool.h>
#include "PLL.h"
#include "I2C.h"
#include "ST7735.h"
#include "VL53L0X.h"
#include "VL53L0X_DEBUG.h"
#include "tm4c123gh6pm.h"
#include "UART.h"

#define INTERNALLED   (*((volatile unsigned long *)0x40025038))
#define EXTERNALLED   (*((volatile unsigned long *)0x4000723C))
#define OFF                     0x00;
#define RED                     0x02;
#define BLUE                    0x04;
#define PINK                    0x06;
#define GREEN                   0x08;
#define YELLOW                  0x0A;
#define LIGHTBLUE               0x0C;
#define WHITE                   0x0E;
// function declarations
void PortF_Init(void);
void PortE_Init(void);

void SystemInit(void){
}

uint8_t i = 0;
uint32_t adcResult[5];
char rxChar[6];

// 1. Pre-processor Directives Section
// Constant declarations to access port registers using 
// symbolic names instead of addresses



//   Global Variables


//   Function Prototypes
void EnableInterrupts(void);
void WaitForInterrupt(void);  // low power mode

void PortF_Init(void) {
	SYSCTL_RCGCGPIO_R |= 0x20;	        // activate Port F clock
	while((SYSCTL_PRGPIO_R&0x20)==0){}; 				// allow time for clock to start
	GPIO_PORTF_CR_R = 0x0E;											
	GPIO_PORTF_DIR_R |= 0x0E;	        	// PF3,2,1 are output
	GPIO_PORTF_DEN_R |= 0x0E;	        	// PF4-0 are digital
}

void PortE_Init(void) {
	SYSCTL_RCGCGPIO_R |= 0x10; 									// activate port E clock
	while((SYSCTL_RCGCGPIO_R&0x10)==0){}; 			// allow time for clock to start
  GPIO_PORTE_DIR_R &= ~0x1F;    // 3) make PE4 PE5 input
  GPIO_PORTE_AFSEL_R |= 0x1F;   // 4) enable alternate function on PE4 PE5
  GPIO_PORTE_DEN_R &= ~0x1F;    // 5) disable digital I/O on PE4 PE5
                  // 5a) configure PE4 as ?? (skip this line because PCTL is for digital only)
  GPIO_PORTE_PCTL_R = GPIO_PORTE_PCTL_R&0xFFF00000;
  GPIO_PORTE_AMSEL_R |= 0x1F;   // 6) enable analog functionality on PE4 PE5
}

void PortD_Init(void) {
  SYSCTL_RCGCGPIO_R |= 0x08;                  // activate port D
  while((SYSCTL_PRGPIO_R&0x08)==0){}; 				// allow time for clock to start
	GPIO_PORTD_LOCK_R  |= 0x4C4F434B;
  GPIO_PORTD_CR_R |= 0x80;		
  GPIO_PORTD_AMSEL_R &= ~0x8F;                // disable analog functionality on PD7,3-0
  GPIO_PORTD_PCTL_R &= ~0xF000FFFF;           // GPIO configure PD7,3-0 as GPIO
  GPIO_PORTD_DIR_R |= 0x8F;                   // make PD7,3-0 out
  GPIO_PORTD_AFSEL_R &= ~0x8F;                // disable alt funct on PD7,3-0
  GPIO_PORTD_DEN_R |= 0x8F;                   // enable digital I/O on PD7,3-0 
}

void ADC_EN(void){            
  volatile uint32_t delay;             
  SYSCTL_RCGCADC_R |= 0x00000001; // 1) activate ADC0
  delay = SYSCTL_RCGCGPIO_R;    // 2) allow time for clock to stabilize
  delay = SYSCTL_RCGCGPIO_R;
  ADC0_PC_R &= ~0xF;        // 8) clear max sample rate field
  ADC0_PC_R |= 0x1;         //  configure for 125K samples/sec
  ADC0_SSPRI_R = 0x3210;      // 9) Sequencer 3 is lowest priority
  ADC0_ACTSS_R &= ~0x0001;    // 10) disable sample sequencer 0
  ADC0_EMUX_R &= ~0x000F;     // 11) seq0 is software trigger
  ADC0_SSMUX0_R = 0x00090123;   // 12) set channels for SS0
  ADC0_SSCTL0_R = 0x00060000;   
  ADC0_IM_R &= ~0x0001;       // 14) disable SS0 interrupts
  ADC0_ACTSS_R |= 0x0001;     // 15) enable sample sequencer 0
}

void UART2_Handler()//this interrupt routine is for receiving data from bluetooth
{
  rxChar[i] = UART2_DR_R;
  i++;
	if(strcmp(rxChar,"0")==0){
		EXTERNALLED ^= 0x01;
		UART3_OutString("0");			
	}
	else if(strcmp(rxChar,"1")==0){
		EXTERNALLED ^= 0x02;
		UART3_OutString("1");
	}
	else if(strcmp(rxChar,"2")==0){
		EXTERNALLED ^= 0x04;
		UART3_OutString("2");
	}
	else if(strcmp(rxChar,"3")==0){
		EXTERNALLED ^= 0x08;
		UART3_OutString("3");	
	}
	else if(strcmp(rxChar,"4")==0){
		EXTERNALLED ^= 0xF0;
		UART3_OutString("4");		
	}
	i=0;
  UART2_ICR_R=UART_ICR_RXIC;//clear interrupt
}

void microsecond_delay(int time){
	int delay;
	SYSCTL_RCGCTIMER_R |= 1;	// enable Timer Block 0
	while((SYSCTL_RCGCTIMER_R&0x01)==0){}; 			// 2) allow time for clock to start
	TIMER0_CTL_R = 0;		// disable Timer before init
	TIMER0_CFG_R = 0x04;		// 16-bit mode
	TIMER0_TAMR_R = 0x01;	// one shot
	TIMER0_TAILR_R = 16-1;	// interval load value register
	TIMER0_ICR_R = 0x1;		// clear Timer0A timeout flag
	TIMER0_CTL_R |= 0x01;		// enable timer0A
	
	for (delay = 0; delay < time; delay++){
  TIMER0_ICR_R = 0x1;
	}

}

//------------ADC_Read------------
// Busy-wait Analog to digital conversion
// Input: none
// Output: two 12-bit result of ADC conversions
// Samples ADC8 and ADC9 
// 125k max sampling
// software trigger, busy-wait sampling
// data returned by reference
// data[0] is ADC8 (PE5) 0 to 4095
// data[1] is ADC9 (PE4) 0 to 4095
void ADC_Read(uint32_t data[5]){ 
  ADC0_PSSI_R = 0x0001;      // 1) initiate SS2
  while((ADC0_RIS_R&0x01)==0){};   // 2) wait for conversion done
  data[0] = ADC0_SSFIFO0_R&0xFFF;  // 3A) read first result
  data[1] = ADC0_SSFIFO0_R&0xFFF;  // 3B) read second result
	data[2] = ADC0_SSFIFO0_R&0xFFF;  // 3A) read third result
  data[3] = ADC0_SSFIFO0_R&0xFFF;  // 3B) read fourth result	
	data[4] = ADC0_SSFIFO0_R&0xFFF;  // 3B) read fifth result	
  ADC0_ISC_R = 0x0001;       // 4) acknowledge completion
}


char* ConvertToKey(uint16_t data){ 
  char* key = "0";
	if (data < 40){
		key = "C1";
	}
	else if (data < 60){
		key = "D1";		
	}
	else if (data < 80){
		key = "E1";		
	}
	else if (data < 100){
		key = "F1";		
	}
	else if (data < 120){
		key = "G1";		
	}
	else if (data < 140){
		key = "A1";		
	}
	else if (data < 160){
		key = "B1";		
	}
	else if (data < 180){
		key = "C2";		
	}
	else if (data < 200){
		key = "D2";		
	}	
	else{
		key = "0";
	}
	return key;
}

// MAIN: Mandatory for a C Program to be executable
int main(void){
	char *flexsensors[10] = {"0","0","0","0","0","0","0","0","0","0"};
	PLL_Init();	//80Mhz
	UART2_Init();	//d6
	UART3_Init();	//c7
  PortF_Init();
	PortE_Init();
	PortD_Init();	
  INTERNALLED = BLUE;
	UART3_OutString("\n\r");
	ADC_EN();
	char OutOfRange = 0;
  PLL_Init();               // bus clock at 80 MHz
	VL53L0X_DEBUG_INIT();
  ST7735_InitR(INITR_REDTAB);
  ST7735_SetCursor(0, 0);
  ST7735_FillScreen(ST7735_BLACK);
  
  // VL53L0X initiziation
  if(!VL53L0X_Init(0)) {
  ST7735_OutString("Fail to init VL53L0X");
  delay(1);
  return 0;
  } 
	else {
  ST7735_OutString("VL53L0X Ready~ ");
  ST7735_OutChar('\n');
  }
  if(!VL53L0X_SingleRanging_Init(0)) {
    ST7735_OutString("SRD Mode init failed :(");
    ST7735_OutChar('\n');
    delay(1);
    return 0;
  } else {
    ST7735_OutString("SRD Mode Ready~ ");
    ST7735_OutChar('\n');
  }
  
  // ST7735 display setup
  ST7735_SetCursor(0, 0);
  ST7735_FillScreen(ST7735_BLACK);
  ST7735_OutString("490A TOF TEST\n");
  ST7735_OutString("--------------------\n");
  
  VL53L0X_RangingMeasurementData_t measurement;
		
  while(1){	

    VL53L0X_getSingleRangingMeasurement(&measurement, 0);
    if (measurement.RangeStatus != 4) {      
      ST7735_SetCursor(0, 2);
      ST7735_OutString("Distance: ");
      ST7735_OutUDec(measurement.RangeMilliMeter);
      ST7735_OutString(" mm \n");
      OutOfRange = 0;
     } 
	  else {
      if (OutOfRange == 0) {
        ST7735_FillRect(0,20,128,10,0);
        ST7735_OutString("Out of range \n");
       OutOfRange = 1;
      }
    }

    ADC_Read(adcResult);
    if (adcResult[0] > 300 ) {  // Red LED on
			INTERNALLED = RED;
			ST7735_SetCursor(0, 4);
			ST7735_OutString("Flex 1 On \n");
			flexsensors[0] = ConvertToKey(measurement.RangeMilliMeter);
		}
		else {
			INTERNALLED &= !RED;
			ST7735_SetCursor(0, 4);
			ST7735_OutString("Flex 1 Off \n");
			flexsensors[0] = "0";
		}
		
		if (adcResult[1] > 300 ) {  // Red LED on
			INTERNALLED = BLUE;
			ST7735_SetCursor(0, 6);
			ST7735_OutString("Flex 2 On \n");
			flexsensors[1] = ConvertToKey(measurement.RangeMilliMeter + 20);
		}
		else {
			INTERNALLED &= !BLUE;
			ST7735_SetCursor(0, 6);
			ST7735_OutString("Flex 2 Off \n");
			flexsensors[1] = "0";
		}
		
		if (adcResult[2] > 300 ) {  // Red LED on
			INTERNALLED = GREEN;
			ST7735_SetCursor(0, 8);
			ST7735_OutString("Flex 3 On \n");
			flexsensors[2] = ConvertToKey(measurement.RangeMilliMeter + 40);			
		}
		else {
			INTERNALLED &= !GREEN;
			ST7735_SetCursor(0, 8);
			ST7735_OutString("Flex 3 Off \n");
			flexsensors[2] = "0";			
		}
		
		if (adcResult[3] > 300 ) {  // Red LED on
			INTERNALLED = YELLOW;
			ST7735_SetCursor(0, 10);
			ST7735_OutString("Flex 4 On \n");
			flexsensors[3] = ConvertToKey(measurement.RangeMilliMeter + 60);						
		}
		else {
			INTERNALLED &= !YELLOW;
			ST7735_SetCursor(0, 10);
			ST7735_OutString("Flex 4 Off \n");
			flexsensors[3] = "0";	
		}
		
		if (adcResult[4] > 300 ) {  // Red LED on
			INTERNALLED = PINK;
			ST7735_SetCursor(0, 12);
			ST7735_OutString("Flex 5 On \n");
			flexsensors[4] = ConvertToKey(measurement.RangeMilliMeter + 80);		
		}
		else {
			INTERNALLED &= !PINK;
			ST7735_SetCursor(0, 12);
			ST7735_OutString("Flex 5 Off \n");
			flexsensors[4] = "0";	
		}
		UART3_OutString(flexsensors[0]);
		UART3_OutString(flexsensors[1]);
		UART3_OutString(flexsensors[2]);
		UART3_OutString(flexsensors[3]);
		UART3_OutString(flexsensors[4]);
		UART3_OutString("\n\r");
		microsecond_delay(500000);
		
  }
}

