// main.c
// Authors: Eric Nguyen, Naomi George
// Created: October 26,2020
// Description: 
// Left glove software for project AirBoard. 
// VL53L0X Library used: https://github.com/ZeeLivermorium/VL53L0X_TM4C123G
// Libray author: Zee Livermorium

//ST7735 connections
//Backlight (pin 10) connected to +3.3 V
//MISO (pin 9) unconnected/ SCK (pin 8) connected to PA2 (SSI0Clk)
//MOSI (pin 7) connected to PA5 (SSI0Tx)
//TFT_CS (pin 6) connected to PA3 (SSI0Fss)
//CARD_CS (pin 5) unconnected
//Data/Command (pin 4) connected to PA6 (GPIO), high for data, low for command
//RESET (pin 3) connected to PA7 (GPIO)
//VCC (pin 2) connected to +3.3 V
//Gnd (pin 1) connected to ground

//VL53L0X connections
//VCC (pin 1) connected to +3.3 V
//Gnd (pin 2) connected to ground
//SCL (pin 3) connected to PB2 (I2C0SCL)
//SDA (pin 4) connected to PB3 (I2C0SDA)
//XSHUT (pin 5) unconnected

// Bluetooth connections
// Tiva -------- HC05 Bluetooth Module
// PD6   ------  TXD
// PC7   ------  RXD
// 3.3v  ------  Vc
// gnd   ------  gnd

// ADC1 connections
// Tiva -------- Flex sensors
// PE0   ------  flex sensor 1
// PE1   ------  flex sensor 2
// PE2   ------  flex sensor 3
// PE3   ------  flex sensor 4
// PE4   ------  flex sensor 5

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "PLL.h"
#include "I2C.h"
#include "ST7735.h"
#include "VL53L0X.h"
#include "VL53L0X_DEBUG.h"
#include "tm4c123gh6pm.h"
#include "UART.h"

#define EXTNLED    (*((volatile unsigned long *)0x4000723C))
#define LED        (*((volatile unsigned long *)0x40025038))
#define OFF        0x00;
#define RED        0x02;
#define BLUE       0x04;
#define PINK       0x06;
#define GREEN      0x08;
#define YELLOW     0x0A;
#define LIGHTBLUE  0x0C;
#define WHITE      0x0E;

// 1. Pre-processor Directives Section
// Constant declarations to access port registers using 
// symbolic names instead of addresses

//   Global Variables
uint32_t adcResult[5]; // array used for storing the ADC data

// Used for storing data chunk gained by breaking up UART 1 data
char flex5[] = "00";
char flex6[] = "00";
char flex7[] = "00";
char flex8[] = "00";
char flex9[] = "00";

// Used for storing the set of flex sensor data for kids mode for the right glove
char flex5KIDS[] = "0";
char flex6KIDS[] = "0";
char flex7KIDS[] = "0";
char flex8KIDS[] = "0";
char flex9KIDS[] = "0";

char rxChar0[20]; // string reserved for use with serial (testing)
char rxChar1[20]; // string reserved for use with UART 1
char rxChar2[20]; // string reserved for use with UART 2 (bluetooth recieve)
char clearrx[] = {"00000000000000000000"};  // string used to clear the bluetooth buffer

// Buffer to break up string recieved from UART
char led0[] = "0";
char led1[] = "0";
char led2[] = "0";
char led3[] = "0";
char led4[] = "0";
char led5[] = "0";
char led6[] = "0";
char led7[] = "0";
char led8[] = "0";
char led9[] = "0";

// String used to store kids mode led data
char *ledArray[10] = {"0","0","0","0","0","0","0","0","0","0"};

// array of strings that acts as the bluetooth data buffer
char *flexsensors[10] = {"00","00","00","00","00","00","00","00","00","00"};
char *flexsensorsKIDS[10] = {"0","0","0","0","0","0","0","0","0","0"};

// Flags to control modes
char LEDflag = 0; // used for controlling external LED output
char kidsModeFlag = 0; // used to signal kids mode
char fullScaleModeFlag = 0; // used to signal full scale mode

// Function Prototypes
void EnableInterrupts(void);
void WaitForInterrupt(void);  // low power mode

// Welcome message to display on serial(for debugging)
char msg_welcome[] = "\n\r490B Airboard Test Left\n\r";

//------------PortF_Init------------
// Used for initializing the onbard LED and push buttons
// Oftened used to quickly test or debug 
// Input: none
// Output: none
void PortF_Init(void) {
	SYSCTL_RCGCGPIO_R |= 0x20;	                // activate Port F clock
	while((SYSCTL_PRGPIO_R&0x20)==0){}; 				// allow time for clock to start
	GPIO_PORTF_LOCK_R  = 0x4C4F434B;	          // unlock commit register
	GPIO_PORTF_CR_R = 0x1F;			                // make PF4 and PF0 configurable
	GPIO_PORTF_DIR_R &= ~0x11;	                // PF4,0 are input
	GPIO_PORTF_DIR_R |= 0x0E;	                  // PF3,2,1 are output
	GPIO_PORTF_DEN_R |= 0x1F;		                // PF4-0 are digital
	GPIO_PORTF_PUR_R |= 0x11;		                // enable pull up for PF4,0            
		                                          // PF4-0 are digital
	GPIO_PORTF_IS_R &= ~0x11;		                // PF4,0 are edge sensitive
	GPIO_PORTF_IBE_R &= ~0x11;	                // PF4,0 are not both edge sensitive
	GPIO_PORTF_IEV_R &= ~0x11;	                // PF4,0 are negedge triggered
	GPIO_PORTF_ICR_R = 0x11;		                // clear int flag on PF4,0
	GPIO_PORTF_IM_R |= 0x11;		                // interrupt on PF4,0
	NVIC_PRI7_R = ( NVIC_PRI7_R & 0xFF00FFFF ) | 0x00200000;	// Set interrupt priority to 5
	NVIC_EN0_R = 1 << 30;	                      // enable IRQ30
}

//------------GPIOPortF_Handler------------
// Interrupt for the port F push buttons
// Currently used to quickly test app bluetooth read
// Sends data to app and turns on onboard LED
// Input: none
// Output: none
void GPIOPortF_Handler(void){
	if((GPIO_PORTF_RIS_R&0x01) == 0x01){   // if push button 2
		GPIO_PORTF_ICR_R = 0x01;
		UART3_OutString("\n\rhello world 1");	
		LED = LIGHTBLUE;         // visually signals that bluetooth data was sent
	}
	else if((GPIO_PORTF_RIS_R&0x10) == 0x10){  // if push button 1
		GPIO_PORTF_ICR_R = 0x10;
		UART3_OutString("\n\rhello world 2");	
		LED = WHITE;             // visually signals that bluetooth data was sent
	}
} 

//------------PortE_Init------------
// Used for initializing ports to be used for the ADC channels
// Input: none
// Output: none
void PortE_Init(void) {
	SYSCTL_RCGCGPIO_R |= 0x10; 									       // activate port E clock
	while((SYSCTL_RCGCGPIO_R&0x10)==0){}; 			       // allow time for clock to start
  GPIO_PORTE_DIR_R &= ~0x1F;                         // make PE4-0 input
  GPIO_PORTE_AFSEL_R |= 0x1F;                        // enable alternate function on PE4-0
  GPIO_PORTE_DEN_R &= ~0x1F;                         // disable digital I/O on PE4-0       
  GPIO_PORTE_PCTL_R = GPIO_PORTE_PCTL_R&0xFFF00000;  // configure PE4-0 as analog
  GPIO_PORTE_AMSEL_R |= 0x1F;                        // enable analog functionality on PE4 PE5
}

//------------PortD_Init------------
// Used for initializing ports to be used to control the 5 external red LEDs
// Input: none
// Output: none
void PortD_Init(void) {
  SYSCTL_RCGCGPIO_R |= 0x08;                  // activate port D
  while((SYSCTL_PRGPIO_R&0x08)==0){};         // allow time for clock to start
  GPIO_PORTD_LOCK_R  |= 0x4C4F434B;           // unlock port PD7
  GPIO_PORTD_CR_R |= 0x80;                    // enable control for PD7
  GPIO_PORTD_AMSEL_R &= ~0x8F;                // disable analog functionality on PD7,3-0
  GPIO_PORTD_PCTL_R &= ~0xF000FFFF;           // GPIO configure PD7,3-0 as GPIO
  GPIO_PORTD_DIR_R |= 0x8F;                   // make PD7,3-0 out
  GPIO_PORTD_AFSEL_R &= ~0x8F;                // disable alt funct on PD7,3-0
  GPIO_PORTD_DEN_R |= 0x8F;                   // enable digital I/O on PD7,3-0 
}


//------------ADC_EN------------
// Used for initializing the ADC with 5 channels
// Input: none
// Output: none
void ADC_EN(void){                        
  volatile uint32_t delay;                         
  SYSCTL_RCGCADC_R |= 0x00000001; // activate ADC0
  delay = SYSCTL_RCGCGPIO_R;      // allow time for clock to stabilize
  delay = SYSCTL_RCGCGPIO_R;
  ADC0_PC_R &= ~0xF;              // clear max sample rate field
  ADC0_PC_R |= 0x1;               // configure for 125K samples/sec
  ADC0_SSPRI_R = 0x3210;          // Sequencer 0 is highest priority
  ADC0_ACTSS_R &= ~0x0001;        // disable sample sequencer 0
  ADC0_EMUX_R &= ~0x000F;         // seq0 is software trigger
  ADC0_SSMUX0_R = 0x00090123;     // set channels for SS0
  ADC0_SSCTL0_R = 0x00060000;     // set channel 5 as the last channel to be read
  ADC0_IM_R &= ~0x0001;           // disable SS0 interrupts
  ADC0_ACTSS_R |= 0x0001;         // enable sample sequencer 0
}

//------------UART2_Handler------------
// ISR that deal with receiving data from bluetooth
// Input: none
// Output: none
void UART2_Handler()
{
	volatile int32_t readback;
	if(UART2_MIS_R & 0x0010){       // if recieving data
		UART2_getString(rxChar2,20);   // read data in as a string with \r as terminating char
		// copy the first value in the data buffer
	  memcpy(led0, rxChar2, 1);
		// if the value is a k enable kids mode and send mode to the right glove
		if(strcmp(led0,"k")==0){
		  kidsModeFlag = 1;
		  fullScaleModeFlag = 0;
      UART1_putString("k\r");		
		}
		// if the value is a f enable full scale mode and send mode to the right glove
		else if(strcmp(led0,"f")==0){
		  fullScaleModeFlag = 1;
		  kidsModeFlag = 0;		
      UART1_putString("f\r");						
		}
		
		// when in kids mode be ready to recieve LED data		
		if (kidsModeFlag == 1){
			// memcpy is used here to tranfer only the data we need from the buffer that is 20 characters long
			memcpy(led0, rxChar2, 1);
			memcpy(led1, (rxChar2 + 1), 1);
			memcpy(led2, (rxChar2 + 2), 1);
			memcpy(led3, (rxChar2 + 3), 1);
			memcpy(led4, (rxChar2 + 4), 1);
			memcpy(led5, (rxChar2 + 5), 1);
			memcpy(led6, (rxChar2 + 6), 1);
			memcpy(led7, (rxChar2 + 7), 1);
			memcpy(led8, (rxChar2 + 8), 1);
			memcpy(led9, (rxChar2 + 9), 1);
			// Transfer the LED data to the led array
			ledArray[0] = led0;
			ledArray[1] = led1;
			ledArray[2] = led2;
			ledArray[3] = led3;
			ledArray[4] = led4;
			ledArray[5] = led5;
			ledArray[6] = led6;
			ledArray[7] = led7;
			ledArray[8] = led8;
			ledArray[9] = led9;
	  }
		LEDflag = 1;                         // Set the LED flag to signify the LEDs to turn on
		memcpy(rxChar2, clearrx, 20);        // clear the bluetooth data buffer
		UART2_ICR_R = UART_ICR_RXIC;         // clear interrupt
		readback = UART2_ICR_R;              // force flags clear
	}
	else if(UART2_MIS_R & 0x0020) {        // if transmiting data 
		UART2_ICR_R |= UART_ICR_TXIC;	       // clear all interrutp flags
		readback = UART2_ICR_R;			         // force flags clear
	}	

}


//------------UART1_Handler------------
// ISR that deal with receiving data from UART 1
// It reads the data and stores it as a string
// Then it will break the string up into chunks
// The chunks represents the notes played by different fingers
// It then updates the bluetooth data buffer flexsensors
// Input: none
// Output: none
void UART1_Handler(void){
	volatile int32_t readback;
	if(UART1_MIS_R & 0x0010){              // if recieving data
		UART1_getString(rxChar1,20);         // read data in as a string with \r as terminating char
		// if in kids mode read in the single letters assigned for each finger
		if (kidsModeFlag == 1){		
			memcpy(flex5KIDS, rxChar1, 1);           // this is the data for the thumb finger (right hand)
			memcpy(flex6KIDS, (rxChar1 + 1), 1);     // this is the data for the index finger (right hand)
			memcpy(flex7KIDS, (rxChar1 + 2), 1);     // this is the data for the middle finger (right hand)
			memcpy(flex8KIDS, (rxChar1 + 3), 1);     // this is the data for the ring finger (right hand)
			memcpy(flex9KIDS, (rxChar1 + 4), 1);     // this is the data for the pinky finger (right hand)
			
			// updating the kids mode bluetooth data buffer with the new values
			flexsensorsKIDS[5] = flex5KIDS;
			flexsensorsKIDS[6] = flex6KIDS;
			flexsensorsKIDS[7] = flex7KIDS;
			flexsensorsKIDS[8] = flex8KIDS;
			flexsensorsKIDS[9] = flex9KIDS;
		}
		// if in full scale mode read in the notes each finger plays
		else if (fullScaleModeFlag == 1){		
			memcpy(flex5, rxChar1, 2);           // this is the data for the thumb finger (right hand)
			memcpy(flex6, (rxChar1 + 2), 2);     // this is the data for the index finger (right hand)
			memcpy(flex7, (rxChar1 + 4), 2);     // this is the data for the middle finger (right hand)
			memcpy(flex8, (rxChar1 + 6), 2);     // this is the data for the ring finger (right hand)
			memcpy(flex9, (rxChar1 + 8), 2);     // this is the data for the pinky finger (right hand)

			// updating the full scale mode bluetooth data buffer with the new values
			flexsensors[5] = flex5;
			flexsensors[6] = flex6;
			flexsensors[7] = flex7;
			flexsensors[8] = flex8;
			flexsensors[9] = flex9;
		}

		UART1_ICR_R |= UART_ICR_RXIC;        // clear all interrutp flags
		readback = UART1_ICR_R;              // force flags clear
	}
	else if(UART1_MIS_R & 0x0020){         // if transmiting data 
		UART1_ICR_R |= UART_ICR_TXIC;	       // clear all interrutp flags
		readback = UART1_ICR_R;			         // force flags clear
	}	
}

//------------microsecond_delay------------
// delay function that create a delay based on microseconds
// uses timer 0 for delay
// Input: time in microseconds
// Output: none
void microsecond_delay(int time){
	int delay;
	SYSCTL_RCGCTIMER_R |= 1;	                  // enable Timer Block 0
	while((SYSCTL_RCGCTIMER_R&0x01)==0){}; 			// allow time for clock to start
	TIMER0_CTL_R = 0;		                        // disable Timer before initialization
	TIMER0_CFG_R = 0x04;		                    // 16-bit mode
	TIMER0_TAMR_R = 0x01;	                      // one shot mode
	TIMER0_TAILR_R = 16-1;	                    // interval load value register
	TIMER0_ICR_R = 0x1;		                      // clear Timer0A timeout flag
	TIMER0_CTL_R |= 0x01;		                    // enable timer0A
	// for loop used for delay
	for (delay = 0; delay < time; delay++){
    TIMER0_ICR_R = 0x1;                       // clear Timer0A timeout flag when done
	}
}

//------------ADC_Read------------
// Busy-wait Analog to digital conversion
// Samples 5 ADC channels
// 125k max sampling
// software trigger, busy-wait sampling
// data returned by reference
// data[0] is AIN9 (PE4) 0 to 4095 (pinky)
// data[1] is AIN0 (PE3) 0 to 4095
// data[2] is AIN1 (PE2) 0 to 4095
// data[3] is AIN2 (PE1) 0 to 4095
// data[4] is AIN3 (PE0) 0 to 4095 (thumb)
// Input: none
// Output: five 12-bit result of ADC conversions
void ADC_Read(uint32_t data[5]){ 
  ADC0_PSSI_R = 0x0001;            // initiate SS2
  while((ADC0_RIS_R&0x01)==0){};   // wait for conversion to finish
  data[4] = ADC0_SSFIFO0_R&0xFFF;  // read first result
	microsecond_delay(100);
  data[3] = ADC0_SSFIFO0_R&0xFFF;  // read second result
  microsecond_delay(100);
	data[2] = ADC0_SSFIFO0_R&0xFFF;  // read third result
	microsecond_delay(100);
  data[1] = ADC0_SSFIFO0_R&0xFFF;  // read fourth result	
	microsecond_delay(100);
	data[0] = ADC0_SSFIFO0_R&0xFFF;  // read fifth result	
	microsecond_delay(100);
  ADC0_ISC_R = 0x0001;             // acknowledge ADC completion
}

//------------ConvertToKey------------
// Note mapping function which converts the distance measured to a note
// Each "note" is 30mm wide
// Standard piano key width is 25mm
// The notes for the left glove are G3-A1
// Input: data is the distance measured plus the offset for the finger
// distance is the distance measured itself
// Output: none
char* ConvertToKey(uint16_t data, uint16_t distance){ 
  char* key = "0";
	uint8_t baseNum = 120;   // offset to have space between wall and glove
													 // makes it so that the sensor does not have to be right next to the wall
	uint8_t keySize = 30;    // value that determines key width
	if (!(distance < 90)){   // minimum distance before a note is assigned
		if (data < baseNum){   // first note
			key = "g3";
		}
		else if (data < (baseNum+keySize)){
			key = "f3";		
		}
		else if (data < (baseNum+(2*keySize))){
			key = "e3";		
		}
		else if (data < (baseNum+(3*keySize))){
			key = "d3";		
		}
		else if (data < (baseNum+(4*keySize))){
			key = "c3";		
		}
		else if (data < (baseNum+(5*keySize))){
			key = "b3";		
		}
		else if (data < (baseNum+(6*keySize))){
			key = "a3";		
		}
		else if (data < (baseNum+(7*keySize))){
			key = "g2";		
		}
		else if (data < (baseNum+(8*keySize))){
			key = "f2";		
		}	
		else if (data < (baseNum+(9*keySize))){
			key = "e2";		
		}	
		else if (data < (baseNum+(10*keySize))){
			key = "d2";		
		}	
		else if (data < (baseNum+(11*keySize))){
			key = "c2";		
		}	
		else if (data < (baseNum+(12*keySize))){
			key = "b2";		
		}	
		else if (data < (baseNum+(13*keySize))){
			key = "a2";		
		}	
		else if (data < (baseNum+(14*keySize))){
			key = "g1";		
		}
		else if (data < (baseNum+(15*keySize))){
			key = "f1";		
		}	
		else if (data < (baseNum+(16*keySize))){
			key = "e1";		
		}	
		else if (data < (baseNum+(17*keySize))){
			key = "d1";		
		}	
		else if (data < (baseNum+(18*keySize))){
			key = "c1";		
		}	
		else if (data < (baseNum+(19*keySize))){
			key = "b1";		
		}	
		else if (data < (baseNum+(14*keySize))){
			key = "a1";		
		}		
		else{
			key = "00";  // if out of range set note to 00
		}
  }
	else {
		key = "00";	   // if too close to the wall set note as 00
	}
	return key;      // return the note
}
//------------main------------
// main that starts the intitializations and hold the main superloop
// Input: none
// Output: none
// MAIN: Mandatory for a C Program to be executable
int main(void){
	char lastSend[21];  // array to store the last data sent to bluetooth
	char LEDlastSend[21];  
	PLL_Init();    // start PLL to set microcontroller clock to 80Mhz
	UART1_Init();  // PB1-tx PB0-rx, UART 1 initialization
	UART2_Init();  // d6, initialization for UART used for bluetooth receive
	UART3_Init();  // c7, initialization for UART used for bluetooth transmit
  PortF_Init();  // port f initializations
	PortE_Init();  // port e initializations
	PortD_Init();  // port d initializations
	
	LED = RED;  // signals that intializations were successful
	ADC_EN();   // turning on the ADC

  char OutOfRange = 0;   // set OutOfRange var to 0 for default state
  VL53L0X_DEBUG_INIT();  // initializing VL53L0X
	
  // ST7735 initializations
  ST7735_InitR(INITR_REDTAB);
  ST7735_SetCursor(0, 0);
  ST7735_FillScreen(ST7735_BLACK);
    
  // VL53L0X start test to ensure it is working
  if(!VL53L0X_Init(0)) {
    ST7735_OutString("Fail to init VL53L0X");  // signals that VL53L0X is not working
    delay(1);
    return 0;
  } 
	else {
    ST7735_OutString("VL53L0X Ready~ ");  // signals that VL53L0X is working
    ST7735_OutChar('\n');
  }
  if(!VL53L0X_SingleRanging_Init(0)) {
    ST7735_OutString("SRD Mode init failed :(");  // signals that VL53L0X is not working in single ranging mode
    ST7735_OutChar('\n');
    delay(1);
    return 0;
  } 
	else {
    ST7735_OutString("SRD Mode Ready~ ");  // signals that VL53L0X is working in single ranging mode
    ST7735_OutChar('\n');
  }
    
  // ST7735 display setup
  ST7735_SetCursor(0, 0);
  ST7735_FillScreen(ST7735_BLACK);  // fill the st7735 screen black
	ST7735_FillRect(0, 0, 128, 10, ST7735_BLACK);  // clear first line
  ST7735_OutString("AIRBOARD\n");  // welcome message for ST7735
  ST7735_OutString("--------------------\n");  // print a border
	
  LED = BLUE;  // signals that VL53L0X and ST7735 are done initializing
	
  VL53L0X_RangingMeasurementData_t measurement;  // name for the structure that holds the VL53L0X data
	
  UART1_putString("\n\r");	// flushing the UART 1
	UART1_putString("\n\r");	
	
	LED = GREEN;  // signals that all initializations are done


	// start of the superloop
  while(1){
		// program or path for the kids/learning mode
		if (kidsModeFlag == 1){
			ADC_Read(adcResult); // read data from the ADC

			// ADC for left hand pinky finger
			if (adcResult[0] > 600 ) {  // if ADC value crosses the thresold a note will be played
				// display note and finger that is playing a note on st7735
				ST7735_SetCursor(0, 4); 
				ST7735_OutString("Flex 1 On \n");
				// update bluetooth data buffer with the note that was played
				flexsensorsKIDS[0] = "a";
			}
			else {  // if ADC value does not crosses the thresold not note will be played
				// update st7735 to show that no finger is being flex and no note is being played
				ST7735_SetCursor(0, 4);
				ST7735_OutString("Flex 1 Off \n");
				// update bluetooth data buffer with no note
				flexsensorsKIDS[0] = "0";	
			}
			
			// ADC for left hand ring finger
			if (adcResult[1] > 600 ) {  // if ADC value crosses the thresold a note will be played
				// display note and finger that is playing a note on st7735
				ST7735_SetCursor(0, 6);
				ST7735_OutString("Flex 2 On \n");
				// update bluetooth data buffer with the note that was played
				flexsensorsKIDS[1] = "b";
			}
			else {  // if ADC value does not crosses the thresold not note will be played
				// update st7735 to show that no finger is being flex and no note is being played
				ST7735_SetCursor(0, 6);
				ST7735_OutString("Flex 2 Off \n");
				// update bluetooth data buffer with no note
				flexsensorsKIDS[1] = "0";
			}
			
			// ADC for left hand middle finger
			if (adcResult[2] > 600 ) {  // if ADC value crosses the thresold a note will be played
				// display note and finger that is playing a note on st7735
				ST7735_SetCursor(0, 8);
				ST7735_OutString("Flex 3 On \n");
				// update bluetooth data buffer with the note that was played
				flexsensorsKIDS[2] = "c";			
			}
			else {  // if ADC value does not crosses the thresold not note will be played
				// update st7735 to show that no finger is being flex and no note is being played
				ST7735_SetCursor(0, 8);
				ST7735_OutString("Flex 3 Off \n");
				// update bluetooth data buffer with no note
				flexsensorsKIDS[2] = "0";
			}
			
			// ADC for left hand index finger
			if (adcResult[3] > 550 ) {  // if ADC value crosses the thresold a note will be played
				// display note and finger that is playing a note on st7735
				ST7735_SetCursor(0, 10);
				ST7735_OutString("Flex 4 On \n");
				// update bluetooth data buffer with the note that was played
				flexsensorsKIDS[3] = "d";
			}
			else {  // if ADC value does not crosses the thresold not note will be played
				// update st7735 to show that no finger is being flex and no note is being played
				ST7735_SetCursor(0, 10);
				ST7735_OutString("Flex 4 Off \n");
				// update bluetooth data buffer with no note
				flexsensorsKIDS[3] = "0";
			}
			
			// ADC for left hand thumb finger
			if (adcResult[4] > 550 ) {  // if ADC value crosses the thresold a note will be played
				// display note and finger that is playing a note on st7735
				ST7735_SetCursor(0, 12);
				ST7735_OutString("Flex 5 On \n");
				// update bluetooth data buffer with the note that was played
				flexsensorsKIDS[4] = "e";	
			}
			else {  // if ADC value does not crosses the thresold not note will be played
				// update st7735 to show that no finger is being flex and no note is being played
				ST7735_SetCursor(0, 12);
				ST7735_OutString("Flex 5 Off \n");
				// update bluetooth data buffer with no note
				flexsensorsKIDS[4] = "0";
			}
			
			// controlling the external red LEDS and sending the right glove the led data for kids mode
			if (LEDflag == 1){
				EXTNLED = 0x00; // turn off all LEDS
				microsecond_delay(10000);
				// check the led array to determine what LED needs to be on
				if(strcmp(ledArray[0],"1")==0){
					EXTNLED |= 0x80;
				}
				else if(strcmp(ledArray[0],"0")==0){
					EXTNLED &= ~0x80;
				}
				
				if(strcmp(ledArray[1],"1")==0){
					EXTNLED |= 0x08;
				}
				else if(strcmp(ledArray[1],"0")==0){
					EXTNLED &= ~0x08;
				}
				
				if(strcmp(ledArray[2],"1")==0){
					EXTNLED |= 0x04;
				}
				else if(strcmp(ledArray[2],"0")==0){
					EXTNLED &= ~0x04;
				}
				
				if(strcmp(ledArray[3],"1")==0){
					EXTNLED |= 0x02;
				}
				else if(strcmp(ledArray[3],"0")==0){
					EXTNLED &= ~0x02;
				}
				
				if(strcmp(ledArray[4],"1")==0){
					EXTNLED |= 0x01;
				}
				else if(strcmp(ledArray[4],"0")==0){
					EXTNLED &= ~0x01;
				}
				
				// sending the led data to the right glove
				UART1_putString(ledArray[5]);
				UART1_putString(ledArray[6]);
				UART1_putString(ledArray[7]);
				UART1_putString(ledArray[8]);
				UART1_putString(ledArray[9]);
				UART1_putString("\r");
				
				// turn off the LED flag
				LEDflag = 0;
		  }

			char LEDtoSend[21];  // string to store data that will be sent to app
			// concatenate data to be sent to app into one string 
			strcpy(LEDtoSend,"0");
			strcat(LEDtoSend,flexsensorsKIDS[0]);
			strcat(LEDtoSend,flexsensorsKIDS[1]);
			strcat(LEDtoSend,flexsensorsKIDS[2]);		
			strcat(LEDtoSend,flexsensorsKIDS[3]);
			strcat(LEDtoSend,flexsensorsKIDS[4]);
			strcat(LEDtoSend,flexsensorsKIDS[5]);
			strcat(LEDtoSend,flexsensorsKIDS[6]);
			strcat(LEDtoSend,flexsensorsKIDS[7]);		
			strcat(LEDtoSend,flexsensorsKIDS[8]);
			strcat(LEDtoSend,flexsensorsKIDS[9]);
			// if the data that will be sent if different from the last data sent then send the new data
			if ((strcmp(LEDtoSend, LEDlastSend) != 0)) {
				// display the most recent data on the LCD
				ST7735_SetCursor(0, 14);
				ST7735_OutString(flexsensorsKIDS[0]);
				ST7735_OutString(flexsensorsKIDS[1]);
				ST7735_OutString(flexsensorsKIDS[2]);
				ST7735_OutString(flexsensorsKIDS[3]);
				ST7735_OutString(flexsensorsKIDS[4]);
				ST7735_OutString(flexsensorsKIDS[5]);
				ST7735_OutString(flexsensorsKIDS[6]);
				ST7735_OutString(flexsensorsKIDS[7]);
				ST7735_OutString(flexsensorsKIDS[8]);
				ST7735_OutString(flexsensorsKIDS[9]);
				// send the new data
				UART3_OutString(flexsensorsKIDS[0]);
				UART3_OutString(flexsensorsKIDS[1]);
				UART3_OutString(flexsensorsKIDS[2]);
				UART3_OutString(flexsensorsKIDS[3]);
				UART3_OutString(flexsensorsKIDS[4]);
				UART3_OutString(flexsensorsKIDS[5]);
				UART3_OutString(flexsensorsKIDS[6]);
				UART3_OutString(flexsensorsKIDS[7]);
				UART3_OutString(flexsensorsKIDS[8]);
				UART3_OutString(flexsensorsKIDS[9]);
			}
				// copy the data that was sent to the app to the last sent buffer
				memcpy(LEDlastSend,LEDtoSend, 21);
	  }
    
		// program or path for the full scale mode
		else if (fullScaleModeFlag == 1){		
			// take a single distance measurement
			VL53L0X_getSingleRangingMeasurement(&measurement, 0);
			
			// check if the distance is in range or not
			if (measurement.RangeStatus != 4) {  // if in range print on the ST7735  
				ST7735_FillRect(0,20,128,10,0);			
				ST7735_SetCursor(0, 2);
				ST7735_OutString("Distance: ");
				ST7735_OutUDec(measurement.RangeMilliMeter);
				ST7735_OutString(" mm \n");
				OutOfRange = 0;
			} 
			else  {
				if (OutOfRange == 0) {  // if not in range print out of range on the ST7735  
					ST7735_FillRect(0,20,128,10,0);
					ST7735_SetCursor(0, 2);
					ST7735_OutString("Out of range \n");
					OutOfRange = 1;
				}
			}
			
			// read data from ADC		
			ADC_Read(adcResult); // read data from the ADC
			
			// ADC for left hand pinky finger
			if (adcResult[0] > 600 ) {  // if ADC value crosses the thresold a note will be played
				// display note and finger that is playing a note on st7735
				ST7735_SetCursor(0, 4); 
				ST7735_OutString("Flex 1 On \n");
				ST7735_OutString("Note = ");
				ST7735_OutString(ConvertToKey(measurement.RangeMilliMeter + 120, measurement.RangeMilliMeter));
				ST7735_OutString("\n");
				// update bluetooth data buffer with the note that was played
				flexsensors[0] = ConvertToKey(measurement.RangeMilliMeter + 120, measurement.RangeMilliMeter);
			}
			else {  // if ADC value does not crosses the thresold not note will be played
				// update st7735 to show that no finger is being flex and no note is being played
				ST7735_SetCursor(0, 4);
				ST7735_OutString("Flex 1 Off \n");
				// update bluetooth data buffer with no note
				flexsensors[0] = "00";	
			}
			
			// ADC for left hand ring finger
			if (adcResult[1] > 600 ) {  // if ADC value crosses the thresold a note will be played
				// display note and finger that is playing a note on st7735
				ST7735_SetCursor(0, 6);
				ST7735_OutString("Flex 2 On \n");
				ST7735_OutString("Note = ");
				ST7735_OutString(ConvertToKey(measurement.RangeMilliMeter + 90, measurement.RangeMilliMeter));
				ST7735_OutString("\n");
				// update bluetooth data buffer with the note that was played
				flexsensors[1] = ConvertToKey(measurement.RangeMilliMeter + 90, measurement.RangeMilliMeter);
			}
			else {  // if ADC value does not crosses the thresold not note will be played
				// update st7735 to show that no finger is being flex and no note is being played
				ST7735_SetCursor(0, 6);
				ST7735_OutString("Flex 2 Off \n");
				// update bluetooth data buffer with no note
				flexsensors[1] = "00";
			}
			
			// ADC for left hand middle finger
			if (adcResult[2] > 600 ) {  // if ADC value crosses the thresold a note will be played
				// display note and finger that is playing a note on st7735
				ST7735_SetCursor(0, 8);
				ST7735_OutString("Flex 3 On \n");
				ST7735_OutString("Note = ");
				ST7735_OutString(ConvertToKey(measurement.RangeMilliMeter + 60, measurement.RangeMilliMeter));
				ST7735_OutString("\n");
				// update bluetooth data buffer with the note that was played
				flexsensors[2] = ConvertToKey(measurement.RangeMilliMeter + 60, measurement.RangeMilliMeter);			
			}
			else {  // if ADC value does not crosses the thresold not note will be played
				// update st7735 to show that no finger is being flex and no note is being played
				ST7735_SetCursor(0, 8);
				ST7735_OutString("Flex 3 Off \n");
				// update bluetooth data buffer with no note
				flexsensors[2] = "00";
			}
			
			// ADC for left hand index finger
			if (adcResult[3] > 550 ) {  // if ADC value crosses the thresold a note will be played
				// display note and finger that is playing a note on st7735
				ST7735_SetCursor(0, 10);
				ST7735_OutString("Flex 4 On \n");
				ST7735_OutString("Note = ");
				ST7735_OutString(ConvertToKey(measurement.RangeMilliMeter + 30, measurement.RangeMilliMeter));
				ST7735_OutString("\n");
				// update bluetooth data buffer with the note that was played
				flexsensors[3] = ConvertToKey(measurement.RangeMilliMeter + 30, measurement.RangeMilliMeter);
			}
			else {  // if ADC value does not crosses the thresold not note will be played
				// update st7735 to show that no finger is being flex and no note is being played
				ST7735_SetCursor(0, 10);
				ST7735_OutString("Flex 4 Off \n");
				// update bluetooth data buffer with no note
				flexsensors[3] = "00";
			}
			
			// ADC for left hand thumb finger
			if (adcResult[4] > 550 ) {  // if ADC value crosses the thresold a note will be played
				// display note and finger that is playing a note on st7735
				ST7735_SetCursor(0, 12);
				ST7735_OutString("Flex 5 On \n");
				ST7735_OutString("Note = ");
				ST7735_OutString(ConvertToKey(measurement.RangeMilliMeter, measurement.RangeMilliMeter));
				ST7735_OutString("\n");
				// update bluetooth data buffer with the note that was played
				flexsensors[4] = ConvertToKey(measurement.RangeMilliMeter, measurement.RangeMilliMeter);	
			}
			else {  // if ADC value does not crosses the thresold not note will be played
				// update st7735 to show that no finger is being flex and no note is being played
				ST7735_SetCursor(0, 12);
				ST7735_OutString("Flex 5 Off \n");
				// update bluetooth data buffer with no note
				flexsensors[4] = "00";
			}
			
			char toSend[21];  // string to store data that will be sent to app
			// concatenate data to be sent to app into one string 
			strcpy(toSend,"0");
			strcat(toSend,flexsensors[0]);
			strcat(toSend,flexsensors[1]);
			strcat(toSend,flexsensors[2]);		
			strcat(toSend,flexsensors[3]);
			strcat(toSend,flexsensors[4]);
			strcat(toSend,flexsensors[5]);
			strcat(toSend,flexsensors[6]);
			strcat(toSend,flexsensors[7]);		
			strcat(toSend,flexsensors[8]);
			strcat(toSend,flexsensors[9]);
			
			// check if the data that will be sent to app matched the data last sent
			// if it does not match send the bluetooth buffer data flexsensor
			if ((strcmp(toSend, lastSend) != 0)) {
				UART3_OutString(flexsensors[0]);
				UART3_OutString(flexsensors[1]);
				UART3_OutString(flexsensors[2]);
				UART3_OutString(flexsensors[3]);
				UART3_OutString(flexsensors[4]);
				UART3_OutString(flexsensors[5]);
				UART3_OutString(flexsensors[6]);
				UART3_OutString(flexsensors[7]);
				UART3_OutString(flexsensors[8]);
				UART3_OutString(flexsensors[9]);
				
				// copy the data that was sent to the app to the last sent buffer
				memcpy(lastSend, toSend, 21);
			}
		}
	}
}

